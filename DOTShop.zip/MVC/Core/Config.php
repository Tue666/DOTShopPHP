<?php  
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', '');
	define('DB_HOST', 'localhost');
	define('DB_SERVERNAME', 'dotshop');

// User define
	define('BASE_URL','http://localhost/DOTShop/');
	define('CSS_URL','http://localhost/DOTShop/Public/css');
	define('IMAGE_URL','http://localhost/DOTShop/Public/images');
	define('JS_URL','http://localhost/DOTShop/Public/js');

// Admin define
	define('ADMIN_BASE_URL','http://localhost/DOTShop/Admin/');
	define('ADMIN_CSS_URL','http://localhost/DOTShop/Public/admin/css');
	define('ADMIN_IMAGE_URL','http://localhost/DOTShop/Public/admin/images');
	define('ADMIN_JS_URL','http://localhost/DOTShop/Public/admin/js');

?>