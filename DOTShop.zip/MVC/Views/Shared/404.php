<?php  
 	echo "This is 404 page";
?>