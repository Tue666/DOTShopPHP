	<div class="content">
		<!-- order-wrapper start -->
		<div class="order-wrapper">
			<!-- order start -->
			<div class="order">
				<img style="width:20%;" src="<?php echo IMAGE_URL.'/success.png' ?>" alt="">
				<label class="success">Order Success. Thanks for your attention :D</label>
				<div class="order-button">
					<button onclick="location.href='<?php echo BASE_URL; ?>'" class="btn btn-success"><i class="fab fa-shopify"></i> Buy more</button>
					<button onclick="location.href='<?php echo BASE_URL; ?>Account/History'" class="btn btn-primary"><i class="fas fa-history"></i> Transaction history</button>
				</div>
			</div>
			<!-- order end -->
		</div>
		<!-- order-wrapper end -->
	</div>